package crudfx;

import javafx.application.Application;
import javafx.collections.*;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.io.*;
import java.util.*;

public class CRUDPersonasFX extends Application {
    static final String ARCHIVO = "personas.txt";
    static ArrayList<Persona> lista = new ArrayList<>();
    static ObservableList<String> observableLista = FXCollections.observableArrayList();

    @Override
    public void start(Stage stage) {
        cargar();
        actualizarLista();

        // --- Componentes de la interfaz ---
        Label titulo = new Label("CRUD de Personas");
        titulo.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        ListView<String> listView = new ListView<>(observableLista);

        TextField nombreField = new TextField();
        nombreField.setPromptText("Nombre");

        TextField edadField = new TextField();
        edadField.setPromptText("Edad");

        Button btnAgregar = new Button("Agregar");
        Button btnEliminar = new Button("Eliminar seleccionado");
        Button btnRefrescar = new Button("Refrescar");

        // --- Acciones de los botones ---
        btnAgregar.setOnAction(e -> {
            try {
                String nombre = nombreField.getText().trim();
                int edad = Integer.parseInt(edadField.getText().trim());
                if (!nombre.isEmpty()) {
                    lista.add(new Persona(nombre, edad));
                    guardar();
                    actualizarLista();
                    nombreField.clear();
                    edadField.clear();
                }
            } catch (NumberFormatException ex) {
                mostrarAlerta("Error", "Edad inválida, ingresa un número.");
            }
        });

        btnEliminar.setOnAction(e -> {
            String seleccion = listView.getSelectionModel().getSelectedItem();
            if (seleccion != null) {
                String nombre = seleccion.split(" \\(")[0];
                lista.removeIf(p -> p.getNombre().equalsIgnoreCase(nombre));
                guardar();
                actualizarLista();
            } else {
                mostrarAlerta("Aviso", "Selecciona una persona para eliminar.");
            }
        });

        btnRefrescar.setOnAction(e -> actualizarLista());

        // --- Layout ---
        VBox inputBox = new VBox(5, nombreField, edadField, btnAgregar, btnEliminar, btnRefrescar);
        inputBox.setPadding(new Insets(10));
        inputBox.setPrefWidth(200);

        BorderPane root = new BorderPane();
        root.setTop(titulo);
        BorderPane.setAlignment(titulo, javafx.geometry.Pos.CENTER);
        root.setCenter(listView);
        root.setRight(inputBox);
        root.setPadding(new Insets(10));

        Scene scene = new Scene(root, 500, 300);
        stage.setTitle("CRUD Personas - JavaFX");
        stage.setScene(scene);
        stage.show();
    }

    // --- Métodos auxiliares ---
    static void actualizarLista() {
        observableLista.clear();
        for (Persona p : lista) {
            observableLista.add(p.toString());
        }
    }

    static void mostrarAlerta(String titulo, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @SuppressWarnings("unchecked")
    static void cargar() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO))) {
            lista = (ArrayList<Persona>) ois.readObject();
        } catch (Exception e) {
            lista = new ArrayList<>();
        }
    }

    static void guardar() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO))) {
            oos.writeObject(lista);
        } catch (IOException e) {
            System.out.println("Error guardando datos.");
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
