import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        // Lista mínima de 5 personas
        List<Persona> personas = Arrays.asList(
                new Persona("Juan", 22, "Bogotá"),
                new Persona("María", 17, "Medellín"),
                new Persona("Carlos", 25, "Bogotá"),
                new Persona("Ana", 30, "Cali"),
                new Persona("Pedro", 19, "Bogotá")
        );

        // (1) Crear una lista de personas y mostrar únicamente los nombres de todas las personas
        System.out.println("1) Nombres de todas las personas:");
        personas.stream()
                .map(Persona::getNombre)
                .forEach(System.out::println);

        // (2) Filtrar e imprimir las personas mayores de edad (18+)
        System.out.println("\n2) Mayores de edad (18+):");
        personas.stream()
                .filter(p -> p.getEdad() >= 18)
                .forEach(System.out::println);

        // (3) Obtener una lista que contenga solo los nombres
        System.out.println("\n3) Lista con solo nombres:");
        List<String> soloNombres = personas.stream()
                .map(Persona::getNombre)
                .collect(Collectors.toList());
        System.out.println(soloNombres);

        // (4) Mensaje nombre + ciudad: “Juan vive en Bogotá”
        System.out.println("\n4) Mensajes 'nombre vive en ciudad':");
        personas.stream()
                .map(p -> p.getNombre() + " vive en " + p.getCiudad())
                .forEach(System.out::println);

        // (5) Mensaje “Hola Juan, tienes 22 años.”
        System.out.println("\n5) Mensajes personalizados (hola + edad):");
        personas.stream()
                .map(p -> "Hola " + p.getNombre() + ", tienes " + p.getEdad() + " años.")
                .forEach(System.out::println);

        // (6) Función que genere una persona aleatoria (nombre, edad y ciudad) y mostrar el resultado
        System.out.println("\n6) Persona aleatoria generada por función:");
        Supplier<Persona> personaAleatoria = () -> {
            Random r = new Random();
            String[] nombres = {"Juan","María","Carlos","Ana","Pedro","Luisa","Sofía","Miguel","Laura","Andrés"};
            String[] ciudades = {"Bogotá","Medellín","Cali","Barranquilla","Bucaramanga","Cartagena"};
            String n = nombres[r.nextInt(nombres.length)];
            String c = ciudades[r.nextInt(ciudades.length)];
            int edad = 10 + r.nextInt(51); // 10 a 60 años
            return new Persona(n, edad, c);
        };
        Persona pRand = personaAleatoria.get();
        System.out.println(pRand);

        // (7) Imprimir los nombres de todas las personas en mayúsculas
        System.out.println("\n7) Nombres en MAYÚSCULAS:");
        personas.stream()
                .map(p -> p.getNombre().toUpperCase())
                .forEach(System.out::println);

        // (8) Filtrar e imprimir únicamente las personas que viven en Bogotá
        System.out.println("\n8) Personas que viven en Bogotá:");
        personas.stream()
                .filter(p -> p.getCiudad().equalsIgnoreCase("Bogotá"))
                .forEach(System.out::println);

        // (9) Lista de mensajes “Juan (22 años) es de Bogotá”
        System.out.println("\n9) Lista de mensajes 'nombre (edad años) es de ciudad':");
        List<String> mensajes = personas.stream()
                .map(p -> p.getNombre() + " (" + p.getEdad() + " años) es de " + p.getCiudad())
                .collect(Collectors.toList());
        mensajes.forEach(System.out::println);
    }
}
