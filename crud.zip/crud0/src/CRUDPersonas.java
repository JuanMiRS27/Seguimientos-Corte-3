import java.io.*;
import java.util.*;

class Persona implements Serializable {
    private String nombre;
    private int edad;

    public Persona(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }

    @Override
    public String toString() {
        return nombre + " (" + edad + ")";
    }
}

public class CRUDPersonas {
    static final String ARCHIVO = "personas.ser";
    static ArrayList<Persona> lista = new ArrayList<>();

    public static void main(String[] args) {
        cargar();
        Scanner sc = new Scanner(System.in);
        int opc;
        do {
            System.out.println("\n--- CRUD PERSONAS ---");
            System.out.println("1. Crear");
            System.out.println("2. Listar");
            System.out.println("3. Eliminar");
            System.out.println("4. Salir");
            System.out.print("Opción: ");
            opc = sc.nextInt(); sc.nextLine();

            switch (opc) {
                case 1 -> crear(sc);
                case 2 -> listar();
                case 3 -> eliminar(sc);
            }
        } while (opc != 4);
        guardar();
    }

    static void crear(Scanner sc) {
        System.out.print("Nombre: ");
        String n = sc.nextLine();
        System.out.print("Edad: ");
        int e = sc.nextInt();
        lista.add(new Persona(n, e));
        guardar();
    }

    static void listar() {
        System.out.println("\nLista:");
        lista.forEach(System.out::println);
    }

    static void eliminar(Scanner sc) {
        System.out.print("Nombre a eliminar: ");
        String nombre = sc.nextLine();
        lista.removeIf(p -> p.getNombre().equalsIgnoreCase(nombre));
        guardar();
    }

    @SuppressWarnings("unchecked")
    static void cargar() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO))) {
            lista = (ArrayList<Persona>) ois.readObject();
        } catch (Exception e) {
            lista = new ArrayList<>();
        }
    }

    static void guardar() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO))) {
            oos.writeObject(lista);
        } catch (IOException e) {
            System.out.println("Error guardando datos.");
        }
    }
}
